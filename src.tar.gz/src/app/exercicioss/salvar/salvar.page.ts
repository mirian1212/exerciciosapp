import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salvar',
  templateUrl: './salvar.page.html',
  styleUrls: ['./salvar.page.scss'],
})
export class SalvarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
