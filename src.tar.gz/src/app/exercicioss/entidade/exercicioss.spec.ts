import { Exercicioss } from './exercicioss';

describe('Exercicioss', () => {
  it('should create an instance', () => {
    expect(new Exercicioss()).toBeTruthy();
  });
});
