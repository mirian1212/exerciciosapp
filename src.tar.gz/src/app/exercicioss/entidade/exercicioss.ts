export class Exercicioss {
  nome: string; 
}
