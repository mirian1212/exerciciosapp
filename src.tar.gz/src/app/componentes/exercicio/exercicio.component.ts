import { Component } from '@angular/core';

@Component({
  selector:'exercicio-component',
  templateUrl:'exercicio.component.html',
  styleUrls: ['exercicio.component.scss']
})

export class ExercicioComponent{

}
