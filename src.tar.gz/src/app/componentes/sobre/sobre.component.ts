import { Component } from '@angular/core';

@Component({
  selector:'sobre-component',
  templateUrl:'sobre.component.html'
})

export class SobreComponent{

}
