import { Estado } from 'src/app/estado/entidade/estado';

export class Pessoa{
nome:string;
email:string;
senha: number;
imc: number;
altura: number;
idade: number;
sexo: string;
nomecidade: string;
}
