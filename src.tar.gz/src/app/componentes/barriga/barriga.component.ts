import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-barriga',
  templateUrl: './barriga.component.html',
  styleUrls: ['./barriga.component.scss'],
})
export class BarrigaComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
