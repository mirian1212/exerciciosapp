import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pernas',
  templateUrl: './pernas.component.html',
  styleUrls: ['./pernas.component.scss'],
})
export class PernasComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
