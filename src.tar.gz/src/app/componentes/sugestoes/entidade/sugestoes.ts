export class Sugestoes {
  sugestoes: string;
}
