import { Component } from '@angular/core';

@Component({
  selector:'loginecadastro-component',
  templateUrl:'loginecadastro.component.html'
})

export class LoginecadastroComponent{

}
