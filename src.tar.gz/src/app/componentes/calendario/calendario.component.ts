import { Component } from '@angular/core';

@Component({
  selector:'calendario-component',
  templateUrl:'calendario.component.html'
})

export class CalendarioComponent{

}
