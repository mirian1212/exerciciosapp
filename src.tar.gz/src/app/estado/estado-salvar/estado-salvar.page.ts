import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estado-salvar',
  templateUrl: './estado-salvar.page.html',
  styleUrls: ['./estado-salvar.page.scss'],
})
export class EstadoSalvarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
