import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estado-listar',
  templateUrl: './estado-listar.page.html',
  styleUrls: ['./estado-listar.page.scss'],
})
export class EstadoListarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
