export class Estado {
}
