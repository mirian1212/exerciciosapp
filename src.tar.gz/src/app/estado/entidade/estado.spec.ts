import { Estado } from './estado';

describe('Estado', () => {
  it('should create an instance', () => {
    expect(new Estado()).toBeTruthy();
  });
});
