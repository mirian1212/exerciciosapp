export class Login{
  email: string;
  senha: string;

}
