import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cidade-listar',
  templateUrl: './cidade-listar.page.html',
  styleUrls: ['./cidade-listar.page.scss'],
})
export class CidadeListarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
